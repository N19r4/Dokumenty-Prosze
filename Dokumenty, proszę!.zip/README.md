# Dokumenty-Prosze
 Console game for programming project
Documentation of the project is named "DokumentacjaProjektuZaliczeniowego.pdf"
